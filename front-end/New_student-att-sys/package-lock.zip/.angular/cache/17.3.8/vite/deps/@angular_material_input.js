import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-NOSUMJMX.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-HHYXZUY4.js";
import "./chunk-C72GZXOU.js";
import "./chunk-5HHZMK2G.js";
import "./chunk-4TV5SJIK.js";
import "./chunk-R2KKISEC.js";
import "./chunk-SBDKQT24.js";
import "./chunk-4HFAPFLP.js";
import "./chunk-FQ46YAEP.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
