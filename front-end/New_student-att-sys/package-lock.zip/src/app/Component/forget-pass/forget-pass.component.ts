import { Component } from '@angular/core';

@Component({
  selector: 'app-forget-pass',
  standalone: true,
  imports: [],
  templateUrl: './forget-pass.component.html',
  styleUrl: './forget-pass.component.css'
})
export class ForgetPassComponent {

}
