import { Component } from '@angular/core';

@Component({
  selector: 'app-attendence-report',
  standalone: true,
  imports: [],
  templateUrl: './attendence-report.component.html',
  styleUrl: './attendence-report.component.css'
})
export class AttendenceReportComponent {

}
