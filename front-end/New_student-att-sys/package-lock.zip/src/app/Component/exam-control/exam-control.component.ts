import { Component } from '@angular/core';

@Component({
  selector: 'app-exam-control',
  standalone: true,
  imports: [],
  templateUrl: './exam-control.component.html',
  styleUrl: './exam-control.component.css'
})
export class ExamControlComponent {

}
