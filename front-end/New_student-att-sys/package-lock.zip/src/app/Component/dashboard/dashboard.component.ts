import { Component } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgChartsModule } from 'ng2-charts';
import { ChartType } from 'chart.js'
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule,NgChartsModule, MatToolbarModule,MatIconModule, MatButtonModule,MatCardModule,MatSidenavModule,MatListModule,FlexLayoutModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  chartOptions = {
    responsive: true,
    maintainAspectRatio: false
  };

  chartLabels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];

  chartData1 = {
    labels: this.chartLabels,
    datasets: [
      {
        data: [65, 59, 80, 81, 56, 55, 40],
        label: 'Series A',
        backgroundColor: ['rgba(255,100,132,0.2)', 'rgba(54,162,235,0.2)', 'rgba(255,206,86,0.2)', 'rgba(75,192,192,0.2)', 'rgba(153,102,255,0.2)', 'rgba(255,159,64,0.2)', 'rgba(255,99,132,0.2)'],
        borderColor: ['rgba(255,99,132,1)', 'rgba(54,162,235,1)', 'rgba(255,206,86,1)', 'rgba(75,192,192,1)', 'rgba(153,102,255,1)', 'rgba(255,159,64,1)', 'rgba(255,99,132,1)'],
        borderWidth: 1
      }
    ]
  };

  chartType1: ChartType = 'pie';  // Use ChartType from 'chart.js'

  chartData2 = {
    labels: this.chartLabels,
    datasets: [
      {
        data: [28, 48, 40, 19, 86, 27, 90],
        label: 'Series B',
        backgroundColor: 'rgba(54,162,235,0.2)',
        borderColor: 'rgba(54,162,235,1)',
        borderWidth: 1
      }
    ]
  };

  chartType2: ChartType = 'bar';  // Use ChartType from 'chart.js'

  chartLegend = true;
}
